This codes comes from https://sites.google.com/site/nicolasgillis/code 

and is described in the paper 

N. Gillis and R. Luce, "A Fast Gradient Method for Nonnegative Sparse Regression with Self Dictionary", IEEE Trans. on Image Processing 27 (1), pp. 24-37, 2018.  