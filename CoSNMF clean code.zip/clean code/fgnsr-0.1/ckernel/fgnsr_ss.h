#ifndef FGNSR_SS_H_INCDEF
#define FGNSR_SS_H_INCDEF

#define FGNSRAPI_SPARSEMAT_MODEL_SS 1

#include "fgnsrdef.h"
#include "proj.h"

#endif /* FGNSR_SS_H_INCDEF */
